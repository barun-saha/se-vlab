

Will require a special getWiring method which handles LayerContainers