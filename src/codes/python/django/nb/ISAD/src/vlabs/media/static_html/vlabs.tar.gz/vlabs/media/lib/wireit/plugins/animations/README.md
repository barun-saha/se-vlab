# WireIt animations plugin


 * Utility to provide Animation on any DOM element containing terminals

 * clearExplode on Layer

